import os,re,uuid,json,shutil

#    ==== 变量模块 ====

# 加工项目路径
Project=os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/__加工项目__/'

# 屏幕过渡界线
TransitionLine='—'*43

# 命令释义字典
CommandsDict=json.load(open(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/z.CommonFunctions/RESOURCES/命令释义字典.json','r'))

# 音效名称字典
SoundsDict=json.load(open(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/z.CommonFunctions/RESOURCES/音效名称字典.json','r'))


#    ==== 函数模块 ====

# 获取项目对象  ()    return 形如{"模组名1": "命名空间1", "模组名2": "命名空间2"...}的字典
def GetModProject():tempReturn={};exec('for temp in os.listdir(Project):tempReturn[temp.replace("&Mod [","").replace("]","")]=open(Project+temp+"/Behavior_Pack/manifest.json","r").read().split("_MNS_")[1]');return tempReturn

# 选择加工模组  ()    return 已选择模组的名称
exec("def PickMod():\n active,temp,tempDict='0',1,{}\n while active not in tempDict:print('请输入需要编辑的Mod序号：');exec(\"for tempModName in GetModProject():print(' '+str(temp)+'. '+tempModName);tempDict[str(temp)],temp=tempModName,temp+1\");active=input('  >>> ');exec(\"exec(\\\"os.system('clear');print(TransitionLine);print('已选择Mod：'+tempDict[active]+'\\\\\\\\n')\\\") if active in tempDict else exec(\\\"os.system('clear');print(TransitionLine);input('该 Mod序号 不存在\\\\\\\\n\\\\\\\\n回车以继续\\\\\\\\n');os.system('clear');print(TransitionLine)\\\")\")\n return tempDict[active]")

# 判断名称合格  (<检测 str>, [模式:1 int/bool])    return 若模式为False且检测只包含大小写字母, 数字与下划线, 则返回True, 否则返回False, 若模式不为False则检测标准包含冒号
exec("def IsNameValid(string,SpaceName=1):\n if SpaceName==False:\n  for strTemp in re.findall(r'[a-z,A-Z,0-9,_]',string):string=string.replace(strTemp,'')\n  if len(string)==0:return True\n  else:return False\n else:\n  for strTemp in re.findall(r'[a-z,A-Z,0-9,:,_]',string):string=string.replace(strTemp,'')\n  if len(string)==0:return True\n  else:return False")

# 命令选择字典  ()    return 已选择的命令
exec("def PickCommand():\n ScreenController().clear()\n while 1:\n  command=input('命令列表：\\n'+'\\n'.join(list(map(replace,list(map(str,list(CommandsDict.items()))))))+'\\n\\n请输入需选择的命令：\\n >>> ')\n  if command in CommandsDict:ScreenController().clear();return command\n  else:ScreenController().clear();input('命令列表：\\n'+'\\n'.join(list(map(replace,list(map(str,list(CommandsDict.items()))))))+'\\n\\n该 命令 不存在\\n\\n回车以继续\\n');ScreenController().clear()");exec("def replace(s):s=s.replace('(\\'',' ').replace('\\', \\'',':').replace('\\')','');return s")


#    ==== 对象模块 ====


# JSON编辑器  (<JSON路径 str>)
#    add(<路径 list>, <内容 str/int/float/bool/list/dict>)    return 添加后JSON路径下的内容
#    delete(<路径 list>)    return 删除后JSON路径下的内容
#    read(<路径 list>)    return 当前的JSON路径下的内容
exec("class openJSON():\n def __init__(self,path):\n  self.path=path\n def add(self,pth,obj):\n  temp,mainPath=json.load(open(self.path,'r')),\"['\"+\"']['\".join(pth)+\"']\"\n  exec('temp'+mainPath+'=\"'+obj+'\"') if type(obj)==str else exec('temp'+mainPath+'='+str(obj))\n  open(self.path,'w').write(json.dumps(temp))\n  return temp\n def delete(self,pth):\n  temp,mainPath=json.load(open(self.path,'r')),\"['\"+\"']['\".join(pth[:len(pth)-1])+\"']\"\n  exec('temp'+mainPath+'.pop(\"'+pth[len(pth)-1]+'\")') if mainPath!=\"['']\" else exec('temp.pop(\"'+pth[len(pth)-1]+'\")')\n  open(self.path,'w').write(json.dumps(temp))\n  return temp\n def read(self,pth):\n  temp=json.load(open(self.path,'r'))\n  return eval('temp'+\"['\"+\"']['\".join(pth)+\"']\") if pth!=[] else temp")


# 屏幕控制工具  ()
#    record(<内容 str>, <名称 str>)    return 记录后的内容名称对象
#    delete(<名称 str>)    return 删除后的内容名称对象
#    repeat(<名称 list>)    return 当前的内容名称对象
#    clear()
exec("class ScreenController():\n def __init__(self):self.LoopContent={}\n def record(self,obj,name):\n  vars,varnum=re.findall('<[a-z,A-Z,0-9,_]{1,999}>',obj),0\n  for var in vars:obj=obj.replace(var,'≡'+str(varnum)+'≡');vars[varnum]=var.replace('<','').replace('>','');varnum+=1\n  self.LoopContent[name]=[obj,vars]\n  return self.LoopContent\n def delete(self,name):\n  del self.LoopContent[name]\n  return self.LoopContent\n def repeat(self,order):\n  for on in order:\n   reason,num=self.LoopContent[on][0],0\n   for var in self.LoopContent[on][1]:\n    reason=self.LoopContent[on][0].replace('≡'+str(num)+'≡',globals()[var]);num+=1\n   print(reason)\n  return self.LoopContent\n def clear(self):os.system('clear');print(TransitionLine)")





#  自 定 义 方 块

# 前置运行
import os
for tempCode in open(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/z.CommonFunctions/CommonFunctions.py','r').readlines():exec(tempCode)
sc=ScreenController();sc.clear()


# 信息输入



# 后台运行




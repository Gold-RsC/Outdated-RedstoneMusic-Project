#  自 定 义 禁 用 物 品

# 前置运行
import os
for tempCode in open(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/z.CommonFunctions/CommonFunctions.py','r').readlines():exec(tempCode)
sc=ScreenController();sc.clear()


# 信息输入
Picked=PickMod()
jsonFile=openJSON(Project+'&Mod ['+Picked+']/Behavior_Pack/config/banned_items.json')
def ComeBack():
    sc.clear()
    print('已选择Mod：'+Picked+'\n')
    PrintBanItems()
    SetBanItems()
def GetBanItems():
    return json.load(open(Project+'&Mod ['+Picked+']/Behavior_Pack/config/banned_items.json','r'))['banned_items']
def PrintBanItems():
    print('该模组已禁物品：')
    exec("for item in GetBanItems():\n print(' '+item)\nprint()") if len(GetBanItems())!=0 else print(' 无\n')
def SetBanItems():
    while 1:
        EditMode=input('请选择编辑模式：\n 1. 添加  2. 删除  3. 查找  4. 退出\n  >>> ')
        if EditMode in map(str,range(1,5)):
            break
        else:
            sc.clear()
            print('已选择Mod：'+Picked+'\n')
            PrintBanItems()
            input('该 编辑模式 不存在\n\n回车以继续\n')
            sc.clear()
            print('已选择Mod：'+Picked+'\n')
            PrintBanItems()
    if EditMode=='1':
        while 1:
            sc.clear()
            print('已选择Mod：'+Picked+'\n')
            PrintBanItems()
            print('编辑模式：1. 添加\n')
            tempItem=input('请输入需禁物品的标识符：\n 如：minecraft:apple\n （输入 / 即可退出）\n  >>> ')
            if tempItem=="/":
                ComeBack()
            if IsNameValid(tempItem)==True:
                if tempItem not in GetBanItems():
                    tempList=GetBanItems();tempList.append(tempItem)
                    jsonFile.add(['banned_items'],tempList)
                else:
                    sc.clear()
                    print('已选择Mod：'+Picked+'\n')
                    PrintBanItems()
                    input('编辑模式：1. 添加\n\n该 物品 已存在\n\n回车以继续\n')
            else:
                sc.clear()
                print('已选择Mod：'+Picked+'\n')
                PrintBanItems()
                input('编辑模式：1. 添加\n\n该 标识符 不合格\n\n回车以继续\n')
    if EditMode=='2':
        while 1:
            sc.clear()
            print('已选择Mod：'+Picked+'\n')
            PrintBanItems()
            if len(GetBanItems())!=0:
                print('编辑模式：2. 删除\n')
                tempItem=input('请输入解禁物品的标识符：\n 如：minecraft:apple\n （输入 / 即可退出）\n  >>> ')
                if tempItem=="/":
                    ComeBack()
                if IsNameValid(tempItem)==True:
                    if tempItem in GetBanItems():
                        tempList=GetBanItems();tempList.remove(tempItem)
                        jsonFile.add(['banned_items'],tempList)
                    else:
                        sc.clear()
                        print('已选择Mod：'+Picked+'\n')
                        PrintBanItems()
                        input('编辑模式：1. 删除\n\n该 物品 不存在\n\n回车以继续\n')
                else:
                    sc.clear()
                    print('已选择Mod：'+Picked+'\n')
                    PrintBanItems()
                    input('编辑模式：1. 删除\n\n该 标识符 不合格\n\n回车以继续\n')
            else:
                input('该模组没有已禁物品\n\n回车以继续\n')
                ComeBack()
    if EditMode=='3':
        while 1:
            sc.clear()
            print('已选择Mod：'+Picked+'\n')
            PrintBanItems()
            if len(GetBanItems())!=0:
                print('编辑模式：3. 查找\n')
                tempItem=input('请输入查找物品的标识符：\n 如：minecraft:apple\n （输入 / 即可退出）\n  >>> ')
                if tempItem=="/":
                    ComeBack()
                if IsNameValid(tempItem)==True:
                    if tempItem in GetBanItems():
                        sc.clear()
                        print('已选择Mod：'+Picked+'\n')
                        PrintBanItems()
                        input('编辑模式：1. 查找\n\n该 物品 存在\n\n回车以继续\n')
                    else:
                        sc.clear()
                        print('已选择Mod：'+Picked+'\n')
                        PrintBanItems()
                        input('编辑模式：1. 查找\n\n该 物品 不存在\n\n回车以继续\n')
                else:
                    sc.clear()
                    print('已选择Mod：'+Picked+'\n')
                    PrintBanItems()
                    input('编辑模式：1. 查找\n\n该 标识符 不合格\n\n回车以继续\n')
            else:
                input('该模组没有已禁物品\n\n回车以继续\n')
                ComeBack()
    if EditMode=='4':
        sc.clear()
        Start()


# 后台运行
def Start(isFirst=False):
    if isFirst==False:
        global Picked
        Picked=PickMod()
    PrintBanItems()
    SetBanItems()
Start(True)

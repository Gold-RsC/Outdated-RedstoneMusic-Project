#  自 定 义 函 数

# 前置运行
import os
for tempCode in open(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/z.CommonFunctions/CommonFunctions.py','r').readlines():exec(tempCode)
sc=ScreenController();sc.clear()


# 信息输入
Picked=PickMod()
sc.record('已选择Mod：<Picked>\n','one')
def mcfunction(m):
    return m.split('.mcfunction')[1]==''
def PrintFiles():
    global files
    files=list(filter(mcfunction,os.listdir(Project+'&Mod ['+Picked+']/Behavior_Pack/functions')))
    print('该模组已存在的函数文件：')
    if len(files)!=0:
        print(' '+'\n '.join(files)+'\n')
        global filesList
        filesList=' '+'\n '.join(files)+'\n'
        sc.record('该模组已存在的函数文件：\n<filesList>','two')
    else:
        print(' 无\n')
        sc.record('该模组已存在的函数文件：\n 无\n','two')
def SetFiles():
    while 1:
        EditMode=input('请选择编辑模式：\n 1. 添加  2. 编辑  3. 功能\n 4. 删除  5. 查找  6. 退出\n  >>> ')
        if EditMode in map(str,range(1,7)):
            sc.record('请选择编辑模式：\n 1. 添加  2. 编辑  3. 功能\n 4. 删除  5. 查找  6. 退出\n  >>> '+EditMode,'three')
            break
        else:
            sc.clear()
            reload()
            sc.repeat(['one','two'])
            input('该 编辑模式 不存在\n\n回车以继续\n')
            sc.clear()
            reload()
            sc.repeat(['one','two'])
    if EditMode=='1':
        while 1:
            filename=input('\n请输入需添加的函数文件名称：\n (仅支持英文字母,数字与下划线)\n （输入 / 即可退出）\n  >>> ')
            if filename=='/':
                sc.clear()
                reload()
                sc.repeat(['one','two'])
                SetFiles()
            unqualified=re.findall('[^\w]',filename)
            if unqualified==[] and filename!='':
                if filename+'.mcfunction' in files:
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    input('\n该 函数文件 已存在\n\n回车以继续\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                else:
                    open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+filename+'.mcfunction','w').write('\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
            else:
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
                input('\n该 函数文件名称 不合格\n\n回车以继续\n')
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
    if EditMode=='2':
        while 1:
            objfile=input('\n请输入需编辑的函数文件名称：\n （输入 / 即可退出）\n  >>> ')
            if objfile=='/':
                sc.clear()
                reload()
                sc.repeat(['one','two'])
                SetFiles()
            unqualified=re.findall('[^\w]',objfile)
            if unqualified==[]:
                if objfile+'.mcfunction' in files:
                    while 1:
                        sc.clear()
                        print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                        content=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','r').readlines()
                        tempnum=0
                        for line in content:
                            tempnum+=1
                            print(str(tempnum)+' '+line,end='')
                        editmode=input('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> ')
                        if editmode=='1':
                            while 1:
                                place=input('\n请输入添加位置：\n 如：a-b表示第a行与第b行之间 (b-a=1)\n （输入 / 即可退出）\n  >>> ')
                                if place=='/':
                                    break
                                if len(place.split('-'))==2 and place.split('-')[0].isnumeric()==True and place.split('-')[1].isnumeric()==True and int(place.split('-')[1])-int(place.split('-')[0])==1 and int(place.split('-')[0])>-1 and int(place.split('-')[1])<=len(content):
                                    un,dn=place.split('-')
                                    command=PickCommand()
                                    filewriter=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','w')
                                    if un=='0':
                                        tempcontent=content
                                        tempcontent[0]=command+' \n'+tempcontent[0]
                                    else:
                                        tempcontent=content
                                        tempcontent[int(un)-1]=tempcontent[int(un)-1]+command+' \n'
                                    for tc in tempcontent:
                                        filewriter.write(tc)
                                    filewriter.close()
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    content=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','r').readlines()
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                                else:
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    input('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode+'\n\n该 添加位置 不规范\n\n回车以继续\n')
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                        elif editmode=='2':
                            while 1:
                                editrow=input('\n请输入编写行数：\n （输入 / 即可退出）\n  >>> ')
                                if editrow=='/':
                                    break
                                if editrow.isnumeric()==True and int(editrow)>0 and int(editrow)<len(content):
                                    tempcontent=content
                                    tempcontent[int(editrow)-1]=content[int(editrow)-1].replace('\n','')+input('\n'+content[int(editrow)-1].replace('\n',''))+'\n'
                                    filewriter=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','w')
                                    for tc in tempcontent:
                                        filewriter.write(tc)
                                    filewriter.close()
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    content=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','r').readlines()
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                                else:
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    input('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode+'\n\n该 行数 不规范\n\n回车以继续\n')
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                        elif editmode=='3':
                            subFunc()
                        elif editmode=='4':
                            while 1:
                                deleterow=input('\n请输入删除范围：\n 如：a-b表示从第a行到第b行(a<b)\n     c表示第c行\n （输入 / 即可退出）\n  >>> ')
                                if deleterow=='/':
                                    break
                                if len(deleterow.split('-'))==2 and deleterow.split('-')[0].isnumeric()==True and deleterow.split('-')[1].isnumeric()==True and int(deleterow.split('-')[0])>0 and int(deleterow.split('-')[1])<len(content) and int(deleterow.split('-')[0])<int(deleterow.split('-')[1]):
                                    head,tail=deleterow.split('-')
                                    tempcontent=content
                                    for times in range(int(tail)-int(head)+1):
                                        del tempcontent[int(head)-1]
                                    filewriter=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','w')
                                    for tc in tempcontent:
                                        filewriter.write(tc)
                                    filewriter.close()
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    content=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','r').readlines()
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                                elif deleterow.isnumeric()==True and int(deleterow)>0 and int(deleterow)<len(content):
                                    tempcontent=content
                                    del tempcontent[int(deleterow)-1]
                                    filewriter=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','w')
                                    for tc in tempcontent:
                                        filewriter.write(tc)
                                    filewriter.close()
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    content=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','r').readlines()
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                                else:
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    input('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode+'\n\n该 删除范围 不规范\n\n回车以继续\n')
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                        elif editmode=='5':
                            while 1:
                                replacerow=input('\n请输入替换范围：\n 如：a-b表示从第a行到第b行(a<b)\n （输入 / 即可退出）\n  >>> ')
                                if replacerow=='/':
                                    break
                                before=input('\n请输入查找内容：\n （输入 / 即可退出）\n  >>> ')
                                if before=='/':
                                    break
                                after=input('\n请输入替换内容：\n （输入 / 即可退出）\n  >>> ')
                                if after=='/':
                                    break
                                if len(replacerow.split('-'))==2 and replacerow.split('-')[0].isnumeric()==True and replacerow.split('-')[1].isnumeric()==True and int(replacerow.split('-')[0])>0 and int(replacerow.split('-')[1])<len(content) and int(replacerow.split('-')[0])<int(replacerow.split('-')[1]):
                                    head,tail=replacerow.split('-')
                                    tempcontent,timesnum=content,0
                                    for times in range(int(tail)-int(head)+1):
                                        tempcontent[int(head)-1]=tempcontent[int(head)-1].replace(before,after)
                                        timesnum+=tempcontent[int(head)-1].count(after)
                                    filewriter=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','w')
                                    for tc in tempcontent:
                                        filewriter.write(tc)
                                    filewriter.close()
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    content=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','r').readlines()
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    input('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode+'\n成功替换了'+timesnum+'次\n\n回车以继续\n')
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    content=open(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+objfile+'.mcfunction','r').readlines()
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                                else:
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    input('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode+'\n\n该 替换范围 不规范\n\n回车以继续\n')
                                    sc.clear()
                                    print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                                    tempnum=0
                                    for line in content:
                                        tempnum+=1
                                        print(str(tempnum)+' '+line,end='')
                                    print('\n请选择操作：\n 1. 添加  2. 编写  3. 功能\n 4. 删除  5. 替换  6. 退出\n  >>> '+editmode)
                        elif editmode=='6':
                            sc.clear()
                            reload()
                            sc.repeat(['one','two','three'])
                            break
                        else:
                            sc.clear()
                            print('已选择Mod：'+Picked+'\n 文件：'+objfile+'\n')
                            tempnum=0
                            for line in content:
                                tempnum+=1
                                print(str(tempnum)+' '+line,end='')
                            input('\n\n该 操作 不存在\n\n回车以继续\n')
                else:
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    input('\n该 函数文件 不存在\n\n回车以继续\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
            else:
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
                input('\n该 函数文件名称 不合格\n\n回车以继续\n')
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
    if EditMode=='3':
        editFunc()
    if EditMode=='4':
        while 1:
            filename=input('\n请输入需删除的函数文件名称：\n （输入 / 即可退出）\n  >>> ')
            if filename=='/':
                sc.clear()
                reload()
                sc.repeat(['one','two'])
                SetFiles()
            unqualified=re.findall('[^\w]',filename)
            if unqualified==[]:
                if filename+'.mcfunction' not in files:
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    input('\n该 函数文件名称 不存在\n\n回车以继续\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                else:
                    os.remove(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+filename+'.mcfunction')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
            else:
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
                input('\n该 函数文件名称 不合格\n\n回车以继续\n')
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
    if EditMode=='5':
        while 1:
            filename=input('\n请输入需查找的函数文件名称：\n （输入 / 即可退出）\n  >>> ')
            if filename=='/':
                sc.clear()
                reload()
                sc.repeat(['one','two'])
                SetFiles()
            unqualified=re.findall('[^\w]',filename)
            if unqualified==[]:
                if filename+'.mcfunction' in files:
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    input('\n该 函数文件 存在\n\n回车以继续\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                else:
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    input('\n该 函数文件 不存在\n\n回车以继续\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
            else:
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
                input('\n该 函数文件名称 不合格\n\n回车以继续\n')
                sc.clear()
                reload()
                sc.repeat(['one','two','three'])
    if EditMode=='6':
        sc.clear()
        Start()
def reload():
    global files,filesList
    files=list(filter(mcfunction,os.listdir(Project+'&Mod ['+Picked+']/Behavior_Pack/functions')))
    filesList=' '+'\n '.join(files)+'\n'
    if len(files)!=0:
        sc.record('该模组已存在的函数文件：\n<filesList>','two')
    else:
        sc.record('该模组已存在的函数文件：\n 无\n','two')
def editFunc():
    while 1:
        funcname=input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> ')
        if funcname=='/':
            sc.clear()
            reload()
            sc.repeat(['one','two'])
            SetFiles()
        if funcname=='1':
            while 1:
                copyneed=input('\n请输入需要复制的函数文件名称：\n （输入 / 即可退出）\n  >>> ')
                if copyneed=='/':
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    break
                if re.findall('[^\w]',copyneed)==[] and copyneed!='':
                    if copyneed+'.mcfunction' in files:
                        while 1:
                            copyname=input('\n请输入复制文件的名称：\n  >>> ')
                            if re.findall('[^\w]',copyname)==[] and copyname!='':
                                if copyname+'.mcfunction' in files:
                                    sc.clear()
                                    reload()
                                    sc.repeat(['one','two','three'])
                                    input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要复制的函数文件名称：\n （输入 / 即可退出）\n  >>> '+copyneed+'\n\n该 名称 已存在\n\n回车以继续\n')
                                    sc.clear()
                                    reload()
                                    sc.repeat(['one','two','three'])
                                    print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要复制的函数文件名称：\n （输入 / 即可退出）\n  >>> '+copyneed)
                                else:
                                    shutil.copyfile(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+copyneed+'.mcfunction',Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+copyname+'.mcfunction')
                                    break
                            else:
                                sc.clear()
                                reload()
                                sc.repeat(['one','two','three'])
                                input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要复制的函数文件名称：\n （输入 / 即可退出）\n  >>> '+copyneed+'\n\n该 名称 不合格\n\n回车以继续\n')
                                sc.clear()
                                reload()
                                sc.repeat(['one','two','three'])
                                print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要复制的函数文件名称：\n （输入 / 即可退出）\n  >>> '+copyneed)
                        sc.clear()
                        reload()
                        sc.repeat(['one','two','three'])
                        print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname)
                    else:
                        sc.clear()
                        reload()
                        sc.repeat(['one','two','three'])
                        input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n该 函数文件 不存在\n\n回车以继续\n')
                        sc.clear()
                        reload()
                        sc.repeat(['one','two','three'])
                        print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname)
                else:
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n该 函数文件名称 不合格\n\n回车以继续\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname)
        elif funcname=='2':
            while 1:
                renameneed=input('\n请输入需要重命名的函数文件名称：\n （输入 / 即可退出）\n  >>> ')
                if renameneed=='/':
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    break
                if re.findall('[^\w]',renameneed)==[] and renameneed!='':
                    if renameneed+'.mcfunction' in files:
                        while 1:
                            renamedname=input('\n请输入重命名文件的名称：\n  >>> ')
                            if re.findall('[^\w]',renamedname)==[] and renamedname!='':
                                if renamedname+'.mcfunction' in files:
                                    sc.clear()
                                    reload()
                                    sc.repeat(['one','two','three'])
                                    input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要重命名的函数文件名称：\n （输入 / 即可退出）\n  >>> '+renameneed+'\n\n该 名称 已存在\n\n回车以继续\n')
                                    sc.clear()
                                    reload()
                                    sc.repeat(['one','two','three'])
                                    print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要重命名的函数文件名称：\n （输入 / 即可退出）\n  >>> '+renameneed)
                                else:
                                    os.rename(Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+renameneed+'.mcfunction',Project+'&Mod ['+Picked+']/Behavior_Pack/functions/'+renamedname+'.mcfunction')
                                    break
                            else:
                                sc.clear()
                                reload()
                                sc.repeat(['one','two','three'])
                                input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要重命名的函数文件名称：\n （输入 / 即可退出）\n  >>> '+renameneed+'\n\n该 名称 不合格\n\n回车以继续\n')
                                sc.clear()
                                reload()
                                sc.repeat(['one','two','three'])
                                print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n请输入需要重命名的函数文件名称：\n （输入 / 即可退出）\n  >>> '+renameneed)
                        sc.clear()
                        reload()
                        sc.repeat(['one','two','three'])
                        print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname)
                    else:
                        sc.clear()
                        reload()
                        sc.repeat(['one','two','three'])
                        input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n该 函数文件 不存在\n\n回车以继续\n')
                        sc.clear()
                        reload()
                        sc.repeat(['one','two','three'])
                        print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname)
                else:
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    input('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname+'\n\n该 函数文件名称 不合格\n\n回车以继续\n')
                    sc.clear()
                    reload()
                    sc.repeat(['one','two','three'])
                    print('\n请输入需选择的功能序号：\n 1. 复制  2. 命名  3. 清空  4. 重写\n （输入 / 即可退出）\n  >>> '+funcname)
        elif funcname=='3':
            pass
        elif funcname=='4':
            pass
        else:
            pass
def subFunc():
    while 1:
        pass
        


# 后台运行
def Start(isFirst=False):
    if isFirst==False:
        global Picked
        Picked=PickMod()
    reload()
    PrintFiles()
    SetFiles()
Start(True)

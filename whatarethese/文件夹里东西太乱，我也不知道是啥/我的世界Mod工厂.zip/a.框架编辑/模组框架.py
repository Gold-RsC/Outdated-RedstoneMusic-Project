
# 前置运行
import os
for tempCode in open(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/z.CommonFunctions/CommonFunctions.py','r').readlines():exec(tempCode)
sc=ScreenController();sc.clear()
ModProjects,SameUuid,behaviorUuid,resourceUuid=GetModProject(),str(uuid.uuid4()),str(uuid.uuid4()),str(uuid.uuid4())


# 信息输入
while 1:
    ModName=input('请输入Mod名称：\n (最多仅32个英文大小写字母)\n  >>> ')
    if ModName.isalpha()==True and len(ModName)<33:
        if ModName not in ModProjects:
            print();break
        else:
            sc.clear()
            input('该 Mod名称 已存在\n\n回车以继续\n')
            sc.clear()
    else:
        sc.clear()
        input('Mod名称 最多仅32个英文大小写字母\n\n回车以继续\n')
        sc.clear()
while 1:
    ModNameSpace=input('请输入Mod命名空间：\n (最多仅32个英文小写字母)\n  >>> ')
    if ModNameSpace.isalpha()==True and ModNameSpace.islower()==True and len(ModNameSpace)<33:
        if ModNameSpace not in ModProjects.values():
            break
        else:
            sc.clear()
            input('请输入Mod名称：\n (最多仅32个英文大小写字母)\n  >>> '+ModName+'\n\n该 Mod命名空间 已存在\n\n回车以继续\n')
            sc.clear()
            print('请输入Mod名称：\n (最多仅32个英文大小写字母)\n  >>> '+ModName+'\n')
    else:
        sc.clear()
        input('请输入Mod名称：\n (最多仅32个英文大小写字母)\n  >>> '+ModName+'\n\nMod命名空间 最多仅32个英文小写字母\n\n回车以继续\n')
        sc.clear()
        print('请输入Mod名称：\n (最多仅32个英文大小写字母)\n  >>> '+ModName+'\n')


# 后台运行
TempBehaviorDirs=[
    ModName+'Scripts/modClient/clientComponent',
    ModName+'Scripts/modClient/clientManager',
    ModName+'Scripts/modClient/clientSystem',
    ModName+'Scripts/modClient/clientUtils',
    ModName+'Scripts/modClient/ui',
    ModName+'Scripts/modCommon/modCommonMgr',
    ModName+'Scripts/modCommon/modCommonUtils',
    ModName+'Scripts/modServer/serverComponent',
    ModName+'Scripts/modServer/serverManager',
    ModName+'Scripts/modServer/serverSystem',
    ModName+'Scripts/modServer/serverUtils',
    'config',
    'entities',
    'functions',
    'loot_tables/blocks',
    'loot_tables/chests',
    'loot_tables/entities',
    'loot_tables/equipment',
    'netease_biomes',
    'netease_blocks',
    'netease_dimension',
    'netease_effects',
    'netease_feature_rules',
    'netease_features',
    'netease_items_beh',
    'netease_recipes',
    'netease_tab',
    'spawn_rules',
    'structures/'+ModNameSpace,
    'trading/economy_trades'
]
for BehaviorDirs in TempBehaviorDirs:
    os.makedirs(Project+'&Mod ['+ModName+']/Behavior_Pack/'+BehaviorDirs)
TempResourceDirs=[
    'animation_controllers',
    'animations',
    'attachables',
    'effects',
    'entity',
    'materials',
    'models/entity',
    'models/netease_block',
    'netease_items_res',
    'particles',
    'render_controllers',
    'sounds',
    'texts',
    'textures/blocks',
    'textures/entity',
    'textures/environment',
    'textures/items',
    'textures/models',
    'textures/particles',
    'textures/sfxs',
    'textures/ui',
    'ui'
]
for ResourceDirs in TempResourceDirs:
    os.makedirs(Project+'&Mod ['+ModName+']/Resource_Pack/'+ResourceDirs)
open(Project+'&Mod ['+ModName+']/Behavior_Pack/manifest.json','w').write('{\n "format_version": 1,\n "header": {\n  "description": " _MNS_'+ModNameSpace+'_MNS_ _INB_False_INB_ ",\n  "version": [ 0, 0, 1 ],\n  "name": "'+ModName+'",\n  "uuid": "'+behaviorUuid+'"\n },\n "modules": [\n  {\n   "description": "behavior",\n   "type": "data",\n   "version": [ 0, 0, 1 ],\n   "uuid": "'+SameUuid+'"\n  }\n ]\n}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/manifest.json','w').write('{\n "format_version": 1,\n "header": {\n  "description": "resource",\n  "version": [ 0, 0, 1 ],\n  "name": "'+ModName+'",\n  "uuid": "'+resourceUuid+'"\n },\n "modules": [\n  {\n   "description": "resource",\n   "type": "resources",\n   "version": [ 0, 0, 1 ],\n   "uuid": "'+SameUuid+'"\n  }\n ]\n}')
open(Project+'&Mod ['+ModName+']/world_behavior_packs.json','w').write('[{"pack_id":"'+behaviorUuid+'","version":[0,0,1]}]')
open(Project+'&Mod ['+ModName+']/world_resource_packs.json','w').write('[{"pack_id":"'+resourceUuid+'","version":[0,0,1]}]')
open(Project+'&Mod ['+ModName+']/Behavior_Pack/config/banned_items.json','w').write('{"banned_items":[]}')
open(Project+'&Mod ['+ModName+']/Behavior_Pack/entities/__init__.py','w')
open(Project+'&Mod ['+ModName+']/Resource_Pack/materials/common.json','w').write('[{"path":"materials/entity.material"}]')
open(Project+'&Mod ['+ModName+']/Resource_Pack/materials/entity.material','w').write('{"materials":{"version":"1.0.0"}}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/sounds/sound_definitions.json','w').write('{}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/sounds/music_definitions.json','w').write('{"game":{"event_name":"music.game","min_delay":600,"max_delay":1200},"water":{"event_name":"music.game.water","min_delay":10,"max_delay":20},"creative":{"event_name":"music.game.creative","min_delay":60,"max_delay":180},"end":{"event_name":"music.game.end","min_delay":60,"max_delay":180},"endboss":{"event_name":"music.game.endboss","min_delay":60,"max_delay":180},"nether":{"event_name":"music.game.nether","min_delay":60,"max_delay":180},"credits":{"event_name":"music.game.credits","min_delay":0,"max_delay":0},"menu":{"event_name":"music.menu","min_delay":0,"max_delay":30}}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/texts/zh_CN.lang','w')
open(Project+'&Mod ['+ModName+']/Resource_Pack/textures/flipbook_textures.json','w').write('[]')
open(Project+'&Mod ['+ModName+']/Resource_Pack/textures/item_texture.json','w').write('{"resource_pack_name":"'+ModName+'","texture_name":"atlas.items","texture_data":{}}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/textures/terrain_texture.json','w').write('{"resource_pack_name":"'+ModName+'","texture_name":"atlas.terrain","texture_data":{}}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/ui/_ui_defs.json','w').write('{"ui_defs":[]}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/biomes_client.json','w').write('{"biomes":{}}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/blocks.json','w').write('{}')
open(Project+'&Mod ['+ModName+']/Resource_Pack/sounds.json','w').write('{"individual_event_sounds":{},"block_sounds":{},"entity_sounds":{},"interactive_sounds":{}}')


# 前置运行
import os
for tempCode in open(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))+'/z.CommonFunctions/CommonFunctions.py','r').readlines():exec(tempCode)
sc=ScreenController();sc.clear()


# 信息输入
def NumProjects():
    projects,num={},1
    for project in GetModProject():
        projects[str(num)]=project;num+=1
    print('模组项目列表：')
    for num in projects:
        print(' '+num+'. '+projects[num])
    print();return projects
def Start():
    ProjectDict=NumProjects()
    need=input('请输入需要删除Mod的序号：\n >>> ')
    if need in ProjectDict:
        YesNo=input('\n是否确定删除：\n 1. 是   2. 否\n  >>> ')
        if YesNo=='1':
            shutil.rmtree(Project+'&Mod ['+ProjectDict[need]+']')
            sc.clear()
            NumProjects()
            input('请输入需要删除Mod的序号：\n >>> '+need+'\n\n该模组已成功删除\n\n回车以继续\n')
            sc.clear()
        elif YesNo=='2':
            sc.clear()
        else:
            sc.clear()
            NumProjects()
            input('该 序号 不存在\n\n回车以继续\n')
            sc.clear()
    else:
        sc.clear()
        NumProjects()
        input('该 序号 不存在\n\n回车以继续\n')
        sc.clear()


# 后台运行
while 1:
    Start()

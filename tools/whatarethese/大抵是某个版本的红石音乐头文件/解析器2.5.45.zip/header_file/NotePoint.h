/*
	Name: MidiFile.h
	Author: Gold_RsC
	Starting Date: 2020/10/3
	Complete Date: 2020/10/5
	Author's website in Bilibili:
		https://space.bilibili.com/361846321?from=search&seid=3387696492724899772
	Description: 
		Copyright belongs to Gold_RsC.
		No reprint without permissio!!!
		 
*/
#ifndef __NOTEPOINT_H__
#define __NOTEPOINT_H__
#include"MidiFile.h"
class Point{
	public:
		//midi tick,game tick,channel,pitch,velocity
		int tick,gt,channel,pitch,velocity;
		//note on(1) or off(0)
		bool type;
		//program
		int prgrm;
		bool operator==(Point&note);
		bool operator!=(Point&note);
		void*operator new(size_t size);
		void operator delete(void*me);
		void*operator new[](size_t size);
		void operator delete[](void*me);
};
bool Point::operator==(Point&note){
	return (this->tick==note.tick&&this->channel==note.channel&&this->pitch==note.pitch&&this->velocity==note.velocity&&this->type==note.type&&this->prgrm==note.prgrm);
}
bool Point::operator!=(Point&note){
	return !(*this==note);
}
void*Point::operator new(size_t size){
	Point*me=(Point*)malloc(size);
	return me;
}
void Point::operator delete(void*me){
	free(me);
}
void*Point::operator new[](size_t size){
	Point*me=(Point*)malloc(size);
	return me;
}
void Point::operator delete[](void*me){
	free(me);
}
class PBPM{
	public:
		//miditick,bpm 
		int tick,value;
		//�൱��gt 
		int preva_sum;
		bool operator==(PBPM&bpm);
		bool operator!=(PBPM&bpm);
		void*operator new(size_t size);
		void operator delete(void*me);
		void*operator new[](size_t size);
		void operator delete[](void*me);
};
bool PBPM::operator==(PBPM&bpm){
	return (this->tick==bpm.tick&&this->value==bpm.value&&this->preva_sum==bpm.preva_sum);
}
bool PBPM::operator!=(PBPM&bpm){
	return !(*this==bpm);
}
void*PBPM::operator new(size_t size){
	PBPM*me=(PBPM*)malloc(size);
	return me;
}
void PBPM::operator delete(void*me){
	free(me);
}
void*PBPM::operator new[](size_t size){
	PBPM*me=(PBPM*)malloc(size);
	return me;
}
void PBPM::operator delete[](void*me){
	free(me);
}
class MidiFun{
	protected:
		int TPQN;
		MidiEvent midi;
		Point*notepoint;
		PBPM*pbpm;
		int nnum;
		int bnum;
		int GAME_TICK_MAX;
		int findbpmidx(PBPM*bpm,int len,int tick);
		void drawline(Point*lp,Point*np,int lpn,int npn,void (*writecmd)(Point,Point));
	public:
		//��Ů�޹� 
		MidiFun();
		//��ʼ�� 
		void init(MidiEvent&midie,Point*note,PBPM*bpm);
		void init(const char*midiname,Point*note,PBPM*bpm);
		//��note��bpm�¼��͵������note��bpm������ 
		//��ȡ�ɹ�����1��ʧ�ܷ���0
		//ʧ��ԭ��
		//1.���鿪�Ĺ�С
		//2.midi���� 
		bool getev(int note_num=10000,int bpm_num=100);
		//����game tick���ֵ 
		int gt_max();
		//����note������ʧ�ܷ���-1(ERROR_EVENT) 
		int note_num();
		//����һ����������
		int bpm_num();
		//���ߣ���ʼ�㣬����(��֪���㣬����������) 
		void makeline(Point&pinit,void (*writecmd)(Point,Point));
};
MidiFun::MidiFun(){
	nnum=ERROR_EVENT;
	bnum=ERROR_EVENT;
	GAME_TICK_MAX=ERROR_EVENT;
}
void MidiFun::init(MidiEvent&midie,Point*note,PBPM*bpm){
	midi=midie;
	notepoint=note;
	pbpm=bpm;
	TPQN=midi.gettpqn();
}
void MidiFun::init(const char*midiname,Point*note,PBPM*bpm){
	midi.read(midiname);
	notepoint=note;
	pbpm=bpm;
	TPQN=midi.gettpqn();
}
void MidiFun::drawline(Point*lp,Point*np,int lpn,int npn,void (*writecmd)(Point,Point)){
//forһ��ample����������˼· 
//**********************************
//�������������� 
// npn||lpn k					|  npn||lpn k
//	5   10  2					|	5   13  3(2)
//	1    2    3    4    5		|	1      2      3      4     5
//	1 2  3 4  5 6  7 8  9 10	|	1 2 3  4 5 6  7 8 9  10 11 12 13
//**********************************
	if(lpn*1.0/npn>1){//lpnΪnpn��k��(k>1) 
		int k=lpn/npn;
		if(k*npn==lpn)
			for(int i=1;i<=npn;i++)
				for(int j=k*(i-1)+1;j<=k*i;j++)
					writecmd(lp[j-1],np[i-1]);
		else{
			for(int i=1;i<=lpn-k*npn;i++)
				for(int j=(k+1)*(i-1)+1;j<=(k+1)*i;j++)
					writecmd(lp[j-1],np[i-1]);
			for(int i=lpn-k*npn+1;i<=npn;i++)
				for(int j=k*(i-1-npn)+lpn+1;j<=k*(i-npn)+lpn;j++)
					writecmd(lp[j-1],np[i-1]);
		}
	}
	else if(npn*1.0/lpn>1){//npnΪlpn��k��(k>1)
		int k=npn/lpn;
		if(k*lpn==npn)
			for(int i=1;i<=lpn;i++)
				for(int j=k*i-k+1;j<=k*i;j++)
					writecmd(lp[i-1],np[j-1]);
		else{
			for(int i=1;i<=npn-k*lpn;i++)
				for(int j=(k+1)*(i-1)+1;j<=(k+1)*i;j++)
					writecmd(lp[i-1],np[j-1]);
			for(int i=npn-k*lpn+1;i<=lpn;i++)
				for(int j=k*(i-1-lpn)+npn+1;j<=k*(i-lpn)+npn;j++)
					writecmd(lp[i-1],np[j-1]);
		}
	}
	else//lpn����npn 
		for(int i=1;i<=npn;i++)
			writecmd(lp[i-1],np[i-1]);
} 
void MidiFun::makeline(Point&pinit,void (*writecmd)(Point,Point)){
//	��ʼ��:
//	1.lpn,npnΪ1
//	2.��lp��һ�ֵΪ��ʼ�㣬��ǰ��ȡnpn��һ�� 
	Point*lp=new Point[128],*np=new Point[128];
	int lpn=1,npn=1;
	lp[0]=pinit;
	for(int i=0;i<nnum;i++){
		if(!notepoint[i].type)continue;
//			ֻҪ np��channel���ʱnote��channel��ͬ 
//			���� np��tick����note��tick 
//			��˵�� ���channel�����������Ѿ����� 
//  	    �� ���� �� ����lp��np
//			���÷���:
//			1.lp,np��� 
//			2.lp�ĵ�һ��Ϊ��ʼ��
//			3.np�ĵ�һ��Ϊnote[i]
//			4.lpn,npn��Ϊ1
		if(
			np[0].channel!=notepoint[i].channel||
			np[0].gt>notepoint[i].gt
		){
			drawline(lp,np,lpn,npn,writecmd);
			memset(lp,0,sizeof(class Point)*128);
			memset(np,0,sizeof(class Point)*128);
			lp[0]=pinit;
			np[0]=notepoint[i];
			lpn=1;
			npn=1;
		}
//		channel��ͬ��ǰ����
//		��˵�� ��channelδ���� 
//		��� tk��ͬ
//		�� ���� �� ����lp,np 
//		���÷���:
//		1.lp��� 
//		2.np��ֲ��lp
//		3.np���
//		4.np�ĵ�һ�note[i]��ֵ
//		5.lpnΪnpn��֮��npn��Ϊ1
		else if(
			np[0].channel==notepoint[i].channel&&
			np[0].gt!=notepoint[i].gt
		){
			drawline(lp,np,lpn,npn,writecmd);
			memset(lp,0,sizeof(class Point)*128);
			for(int j=0;j<npn;j++)
				lp[j]=np[j];
			memset(np,0,sizeof(class Point)*128);
			np[0]=notepoint[i];
			lpn=npn;
			npn=1;
		}
//		channel��ͬ��ǰ���� 
//		���tk��ͬ 
//		�� else����������� 
//		�� ��np������note[i]
		else
			np[npn++]=notepoint[i];
	}
//	����ʣ�µĵ� 
	drawline(lp,np,lpn,npn,writecmd);
	delete[] np;
	delete[] lp;
}
int MidiFun::findbpmidx(PBPM*bpm,int len,int tick){
	int l=0,r=len-1;
	if(tick>=bpm[r].tick)
		return r;
	if(tick<bpm[l].tick)
		return ERROR_EVENT;
	while(l<=r){
		int mid=(l+r)/2;
		if(tick<bpm[mid].tick)
			r=mid;
		else if(tick>=bpm[mid+1].tick)
			l=mid+1;
		else
			return mid;
	}
	return ERROR_EVENT;
}
bool MidiFun::getev(int note_num,int bpm_num){
	NOTE*note=new NOTE[note_num];
	BPM*bpm=new BPM[bpm_num];
	nnum=midi.getnote(note,note_num);
	if(nnum==ERROR_EVENT)
		return 0;
	bnum=midi.getbpm(bpm,bpm_num);
	if(bnum==ERROR_EVENT)
		return 0;
	for(int bpmidx=0;bpmidx<bnum;bpmidx++){
		pbpm[bpmidx].value=bpm[bpmidx].value;
		pbpm[bpmidx].tick=bpm[bpmidx].tick;
		pbpm[bpmidx].preva_sum=
			(bpmidx==0?0:pbpm[bpmidx-1].preva_sum)
			+(pbpm[bpmidx].tick-(bpmidx==0?0:pbpm[bpmidx-1].tick))
			*1200/TPQN
			/(bpmidx==0?1:pbpm[bpmidx-1].value);
	}
	for(int noteidx=0;noteidx<nnum;noteidx++){
		notepoint[noteidx].tick=note[noteidx].tick;
		notepoint[noteidx].channel=note[noteidx].channel;
		notepoint[noteidx].pitch=note[noteidx].pitch;
		notepoint[noteidx].velocity=note[noteidx].velocity;
		notepoint[noteidx].type=note[noteidx].type;
		notepoint[noteidx].prgrm=note[noteidx].prgrm;
		int bpmidx=findbpmidx(pbpm,bnum,notepoint[noteidx].tick);
		if(bpmidx==ERROR_EVENT)
			return 0;
		notepoint[noteidx].gt=
			pbpm[bpmidx].preva_sum
			+(notepoint[noteidx].tick-pbpm[bpmidx].tick)
			*1200/TPQN/pbpm[bpmidx].value;
		GAME_TICK_MAX=(GAME_TICK_MAX<notepoint[noteidx].gt?notepoint[noteidx].gt:GAME_TICK_MAX);
	}
	delete[] note;
	delete[] bpm;
	return 1;
}
int MidiFun::bpm_num(){
	return bnum;
}
int MidiFun::note_num(){
	return nnum;
}
int MidiFun::gt_max(){
	return GAME_TICK_MAX;
}
#endif

